<section class="section">
    <div class="container">
        <div class="section-heading section-heading--center">
            <h2><?php echo trans('terms-of-service') ?></h2>
        </div>

        <div class="spacer py-6"></div>

        <div class="row">
            <div class="col-12">

                <div class="content-container">
                    <div class="faq">
                        <div class="accordion-container">
                            <p><?php echo settings()->terms_service; ?></p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>